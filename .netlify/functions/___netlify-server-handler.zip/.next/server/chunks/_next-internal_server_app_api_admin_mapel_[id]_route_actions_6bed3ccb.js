module.exports=[327772,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_mapel_%5Bid%5D_route_actions_6bed3ccb.js.map